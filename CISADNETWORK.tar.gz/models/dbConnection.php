<?php

     function getInfoDb() {
        return ['user' => 'root', 'pass' => 'adrian', 'host' => 'localhost', 'db' => 'cisadnetwork'];
    }

?>
