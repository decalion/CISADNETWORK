<h1>Who we are?</h1>
<p>We are a group of studiats that embarked on this journey to achieve our goal, to make a social network with a diferent pourpose.</p>
<p>We like to share our opinions on all fields, so we created this platform for a better share of yours opinion to your friends.</p>