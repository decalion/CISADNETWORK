<?php

    loadDefault('movies', $link);

?>