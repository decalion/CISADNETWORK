<?php

    loadDefault('series', $link);

?>