<h1>Rules</h1>
<div style='left: 3%; position: relative;'>
    <ol>
        <li>Don't insult.</li>
        <li>Don't spam another users.</li>
        <li>Respect users opinions.</li>
        <li>Don't upload disrespectful material.</li>
    </ol>
</div>