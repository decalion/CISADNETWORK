<?php

    loadDefault('rules');

?>