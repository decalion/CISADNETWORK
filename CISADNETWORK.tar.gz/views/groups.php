<?php

    loadDefault('groups', $link);

?>