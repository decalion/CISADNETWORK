<?php

   $log['msg'] = '<p>'.$_POST['userInputSearch'].'</p>';
   
   

?>