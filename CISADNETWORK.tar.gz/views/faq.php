<?php

    loadDefault('faq');

?>