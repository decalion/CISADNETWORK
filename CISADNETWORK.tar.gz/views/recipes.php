<?php

    loadDefault('recipes', $link);

?>