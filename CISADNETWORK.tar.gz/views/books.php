<?php

    loadDefault('books', $link);

?>