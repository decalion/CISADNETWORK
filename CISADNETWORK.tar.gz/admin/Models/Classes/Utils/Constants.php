<?php

/**
 * BD CONST
 */
const HOST="localhost";
const USER="root";
const PASS="icaballero23";
const DATABASE="cisadnetwork";
  

/**
 * IDS CONST
 */
const BACK=1;
const LOGOUT=10;
const AUTHENTICATION=100;
const USERPANEL=101;
const USERMODIFY=102;
const SAVEMODIFYUSER=103;
const USERDELETED=104;
const CONFUSERDELETED=105;






?>